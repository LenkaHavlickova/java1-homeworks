package cz.czechitas.banka;

public class SporiciUcet extends Ucet {

    private double urokovaMira;

    public SporiciUcet(double pocatecniCastka) {
        zustatek = pocatecniCastka;
    }

    public SporiciUcet(double pocatecniCastka, double pocatecniUrokovaMira) {
        zustatek = pocatecniCastka;
        urokovaMira = pocatecniUrokovaMira;
    }


    public double getUrokovaMira() {
        return urokovaMira;
    }


    public void vypocitejRocniUrokAVlozHoNaUcet () {
        double prisaneUroky = zustatek * urokovaMira;
        vlozPenize(prisaneUroky);
    }
}
