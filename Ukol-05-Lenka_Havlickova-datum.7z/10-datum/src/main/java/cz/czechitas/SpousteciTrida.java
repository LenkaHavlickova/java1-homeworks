package cz.czechitas;

import sun.util.resources.it.*;

public class SpousteciTrida {

    public static void main(String[] args) {
        Datum dnesek = new Datum();
        dnesek.setRok(2019);
        dnesek.setMesic(10);
        dnesek.setDen(26);

        System.out.println(dnesek);
        System.out.println("Mesic: " + dnesek.getNazevMesice(dnesek.getMesic()));

        System.out.println();

        Datum letosniVanoce = new Datum();
        letosniVanoce.setDen(24);
        letosniVanoce.setMesic(12);
        letosniVanoce.setRok(2019);
        System.out.println(letosniVanoce);

        Datum letosniSilvestr = new Datum();
        letosniSilvestr.setRok(2019);
        letosniSilvestr.setMesic(12);
        letosniSilvestr.setDen(31);
        System.out.println(letosniSilvestr);

        if (letosniVanoce.getMesic() == letosniSilvestr.getMesic()) {
            System.out.println("Vanoce a Silvestr jsou ve stejnem mesici.");
        } else {
            System.out.println("Vanoce a Silvestr NEJSOU ve stejnem mesici.");
        }

        System.out.println();

        Datum nesmyslnyMesic = new Datum();
        nesmyslnyMesic.setRok(2020);
        nesmyslnyMesic.setMesic(13);
        nesmyslnyMesic.setDen(11);
        System.out.println(nesmyslnyMesic);

        System.out.println();

        Datum nesmyslnyMesic2 = new Datum();
        nesmyslnyMesic2.setRok(2021);
        nesmyslnyMesic2.setMesic(-1);
        nesmyslnyMesic2.setDen(5);
        System.out.println(nesmyslnyMesic2);

        System.out.println();

        Datum nesmyslnyDen = new Datum();
        nesmyslnyDen.setRok(2022);
        nesmyslnyDen.setMesic(12);
        nesmyslnyDen.setDen(40);
        System.out.println(nesmyslnyDen);

        System.out.println();

        Datum nesmyslnyDen2 = new Datum();
        nesmyslnyDen2.setRok(2023);
        nesmyslnyDen2.setMesic(3);
        nesmyslnyDen2.setDen(-2);
        System.out.println(nesmyslnyDen2);

        System.out.println();

        Datum nesmyslnyDen3 = new Datum();
        nesmyslnyDen3.setRok(2019);
        nesmyslnyDen3.setMesic(2);
        nesmyslnyDen3.setDen(29);
        System.out.println(nesmyslnyDen3);

        System.out.println();

        Datum posledniUnor = new Datum();
        posledniUnor.setRok(2020);
        posledniUnor.setMesic(2);
        posledniUnor.setDen(29);
        System.out.println(posledniUnor);

        System.out.println();

        Datum nesmyslnyDen4 = new Datum();
        nesmyslnyDen4.setRok(2019);
        nesmyslnyDen4.setMesic(6);
        nesmyslnyDen4.setDen(31);
        System.out.println(nesmyslnyDen4);

        System.out.println();

        Datum nesmyslnyMesic3 = new Datum();
        nesmyslnyMesic3.setRok(2019);
        nesmyslnyMesic3.setDen(31);
        nesmyslnyMesic3.setMesic(9);
        System.out.println(nesmyslnyMesic3);

        System.out.println();

        Datum posledniDenPrazdnin = new Datum();
        posledniDenPrazdnin.setRok(2019);
        posledniDenPrazdnin.setDen(31);
        posledniDenPrazdnin.setMesic(8);
        System.out.println(posledniDenPrazdnin);
    }

}
