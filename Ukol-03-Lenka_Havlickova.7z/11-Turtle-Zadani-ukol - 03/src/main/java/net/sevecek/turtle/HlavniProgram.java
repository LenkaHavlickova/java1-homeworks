package net.sevecek.turtle;

import java.awt.*;
import com.oracle.webservices.internal.impl.encoding.*;
import com.sun.org.apache.xalan.internal.xsltc.dom.*;
import net.sevecek.turtle.engine.*;
import sun.font.*;

public class HlavniProgram {

    Turtle zofka;

    public void main(String[] args) {
        zofka = new Turtle();

        zofka.setLocation(200, 400);
        nakresliSnehulaka(60);
        jedVpravo(50);
        nakresliVlak(75, 2);
        zofka.setLocation(100, 300);
        nakresliZmrzlinu(60, 30);
        }

    public void nakresliVlak(double delkaRadlice, int pocetVagonku) {
        nakresliLokomotivu(delkaRadlice);
        for (int i = 0; i < pocetVagonku; i++) {
            nakresliVagonek(delkaRadlice);
        }

    }

    public void nakresliLokomotivu(double delkaRadlice) {
        double zakladna;
        zakladna = vypoctiZakladnuTrojuhelniku(delkaRadlice, 90);
        zofka.turnLeft(45);
        zofka.setPenColor(Color.orange);
        nakresliRovnoramennyTrojuhelnik(delkaRadlice, 90);
        zofka.turnRight(90);
        zofka.move(zakladna);
        zofka.turnLeft(45);
        zofka.setPenColor(Color.BLUE);
        nakresliObdelnik(delkaRadlice, 2);
        zofka.move(delkaRadlice / 2);
        zofka.turnRight(90);
        zofka.move(delkaRadlice / 2);
        zofka.turnLeft(180);
        nakresliObdelnik(delkaRadlice / 3, 2);
        zofka.turnRight(90);
        jedDolu(delkaRadlice);
        zofka.turnRight(90);
        zofka.setPenColor(Color.red);
        nakresliKruznici(30, delkaRadlice / 4, 1);
        jedNahoru(delkaRadlice);
        nakresliKruznici(30, delkaRadlice / 4, 1);
        jedNahoru(delkaRadlice);
        zofka.turnLeft(180);
        zofka.setPenColor(Color.BLUE);
        nakresliObdelnik(delkaRadlice, 2);
        jedDolu(delkaRadlice * 0.4);
        zofka.turnLeft(90);
        zofka.setPenColor(Color.red);
        nakresliKruznici(40, delkaRadlice * 0.4, 0.475);
        jedVpravo(delkaRadlice * 0.3);
        jedNahoru(delkaRadlice * 1.2);
        zofka.setPenColor(Color.BLUE);
        zofka.turnLeft(90);
        nakresliObdelnik(delkaRadlice * 0.25, 2);
        zofka.turnRight(90);
        jedNahoru(delkaRadlice * 0.8);
        jedVlevo(delkaRadlice * 0.4);
        jedNahoru(delkaRadlice * 0.1);
        jedVlevo(delkaRadlice * 0.25);
        zofka.setPenColor(Color.red);
        nakresliObdelnik(delkaRadlice * 0.2, 7);
        jedDolu(delkaRadlice * 2.1);
        jedVpravo(delkaRadlice * 1.25);

    }

    public void nakresliVagonek(double delkaRadlice) {
        zofka.setPenColor(Color.black);
        zofka.turnRight(90);
        zofka.move(delkaRadlice);
        zofka.turnLeft(90);
        jedNahoru(delkaRadlice);
        zofka.setPenColor(Color.BLUE);
        nakresliObdelnik(delkaRadlice * 2, 1.5);
        jedDolu(delkaRadlice);
        jedVpravo(delkaRadlice / 2);
        zofka.turnRight(90);
        zofka.setPenColor(Color.red);
        nakresliKruznici(30, delkaRadlice / 4, 1);
        jedNahoru(delkaRadlice);
        nakresliKruznici(30, delkaRadlice / 4, 1);
        jedNahoru(delkaRadlice);
        nakresliKruznici(30, delkaRadlice / 4, 1);
        zofka.turnLeft(90);
        jedNahoru(delkaRadlice);
        zofka.turnLeft(90);
        zofka.setPenColor(Color.BLUE);
        nakresliObdelnik(delkaRadlice / 2, 1.5);
        jedNahoru(delkaRadlice);
        nakresliObdelnik(delkaRadlice / 2, 1.5);
        jedNahoru(delkaRadlice);
        nakresliObdelnik(delkaRadlice / 2, 1.5);
        zofka.turnRight(90);
        jedNahoru(delkaRadlice * 1.1);
        jedVlevo(delkaRadlice * 0.8);
        zofka.setPenColor(Color.red);
        nakresliObdelnik(delkaRadlice * 0.2, 18);
        jedDolu(delkaRadlice * 2.1);
        jedVpravo(delkaRadlice * 3.3);
    }

    public void nakresliObdelnik(double stranaKratsi, double nasobekDelsiStrany) {
        double stranaDelsi;
        stranaDelsi = nasobekDelsiStrany * stranaKratsi;
        zofka.move(stranaKratsi / 2);
        zofka.turnRight(90);
        zofka.move(stranaDelsi);
        zofka.turnRight(90);
        zofka.move(stranaKratsi);
        zofka.turnRight(90);
        zofka.move(stranaDelsi);
        zofka.turnRight(90);
        zofka.move(stranaKratsi / 2);

    }

    public void nakresliSnehulaka(double spodniKoule) {
        zofka.setPenColor(Color.CYAN);
        double stredniKoule;
        stredniKoule = spodniKoule * 0.75;
        double horniKoule;
        horniKoule = spodniKoule * 0.5;
        double bocniKoule;
        bocniKoule = spodniKoule * 0.3;
//    telo snehulaka
        nakresliKruznici(40, spodniKoule, 1);
        jedVpravo(spodniKoule - stredniKoule);
        jedNahoru(spodniKoule + stredniKoule);
        nakresliKruznici(40, stredniKoule, 1);
        jedVlevo(bocniKoule * 2);
        nakresliKruznici(40, bocniKoule, 1);
        jedVpravo(bocniKoule * 2 + stredniKoule * 2);
        nakresliKruznici(40, bocniKoule, 1);
        jedVlevo(stredniKoule + horniKoule);
        jedNahoru(stredniKoule + horniKoule);
        nakresliKruznici(40, horniKoule, 1);
//        hrnec na hlave
        zofka.penUp();
        zofka.turnRight(30);
        double odvesna;
        odvesna = vypoctiOdvesnu(horniKoule, 60);
        zofka.move(odvesna);
        zofka.turnLeft(30);
        zofka.penDown();
        zofka.setPenColor(Color.red);
        zofka.move(horniKoule);
        zofka.turnRight(90);
        zofka.move(horniKoule);
        zofka.turnRight(90);
        zofka.move(horniKoule);
        zofka.turnRight(180);
        zofka.move(horniKoule / 2);
        nakresliKruznici(40, horniKoule * 0.2, 1);
        zofka.penUp();
//        oblicej
        jedDolu(horniKoule);
        jedVlevo(horniKoule * 0.1);
        zofka.penDown();
        zofka.setPenColor(Color.BLACK);
        double uhlik;
        uhlik = horniKoule * 0.05;
        zofka.setPenWidth(5);
        nakresliKruznici(20, uhlik, 1);
        jedVlevo(horniKoule * 0.90);
        nakresliKruznici(20, uhlik, 1);
        jedDolu(horniKoule * 0.75);
        nakresliKruznici(20, uhlik, 1);
        jedVpravo(horniKoule * 0.9);
        nakresliKruznici(20, uhlik, 1);
        jedVlevo(horniKoule * 0.45);
        jedDolu(horniKoule * 0.2);
        nakresliKruznici(20, uhlik, 1);
        jedNahoru(horniKoule * 0.7);
        zofka.turnRight(105);
        zofka.setPenColor(Color.orange);
        zofka.move(horniKoule * 0.6);
        zofka.turnRight(150);
        zofka.move(horniKoule * 0.6);
        zofka.turnRight(105);
//        knofliky
        jedDolu(horniKoule * 0.85 + stredniKoule * 0.5);
        zofka.setPenColor(Color.BLACK);
        nakresliKruznici(20, uhlik, 1);
        jedDolu(stredniKoule * 0.5);
        nakresliKruznici(20, uhlik, 1);
        jedDolu(stredniKoule * 0.5);
        nakresliKruznici(20, uhlik, 1);
        jedDolu(stredniKoule * 0.5 + spodniKoule * 0.5);
        nakresliKruznici(20, uhlik, 1);
        jedDolu(spodniKoule * 0.5);
        nakresliKruznici(20, uhlik, 1);
        jedDolu(spodniKoule * 0.5);
        nakresliKruznici(20, uhlik, 1);
        jedDolu(spodniKoule * 0.5);
//        koste
        jedNahoru(spodniKoule * 2 + stredniKoule + bocniKoule);
        jedVpravo(stredniKoule + bocniKoule);
        zofka.setPenColor(new Color(154, 66, 13));
        zofka.move(bocniKoule);
        zofka.turnLeft(60);
        for (int i = 0; i < 5; i++) {
            zofka.move(bocniKoule * 2);
            zofka.turnRight(180);
            zofka.move(bocniKoule * 2);
            zofka.turnLeft(150);
        }
        zofka.turnLeft(90);
        jedDolu(bocniKoule * 3);
        zofka.turnRight(180);
        zofka.move(bocniKoule * 4);
        zofka.turnRight(180);
        jedDolu(spodniKoule);
        jedVpravo(spodniKoule);
        zofka.setPenWidth(10);
    }

    public double vypoctiOdvesnu(double prepona, double uhel) {
        double vysledek;
        vysledek = 2 * prepona * Math.cos(Math.toRadians(60));
        return vysledek;
    }

    public void nakresliZmrzlinu(double delkaRamene, double sevrenyUhel) {
        zofka.setPenColor(Color.orange);
        nakresliRovnoramennyTrojuhelnik(delkaRamene, sevrenyUhel);
        zofka.turnLeft(45);
        double polomer;
        polomer = vypoctiPolomer(delkaRamene, sevrenyUhel);
        zofka.setPenColor(Color.red);
        nakresliKruznici(40, polomer, 0.72);
        zofka.turnRight(134);
        jedDolu(100);
    }

    public double vypoctiPolomer(double delkaRamene, double sevrenyUhel) {
        double zakladna;
        zakladna = vypoctiZakladnuTrojuhelniku(delkaRamene, sevrenyUhel);
        double vysledek;
        vysledek = zakladna * Math.sqrt(0.5);
        return vysledek;
    }

    public void nakresliPravidelnyNUhlenik(int pocetStran, double delkaStrany, double cast) {
        zofka.move(delkaStrany / 2);
        for (int i = 0; i < (pocetStran - 1) * cast; i++) {
            zofka.turnRight(360.00 / pocetStran);
            zofka.move(delkaStrany);
        }
        zofka.turnRight(360.00 / pocetStran);
        zofka.move(delkaStrany / 2);
    }

    public void nakresliKruznici(int pocetHran, double polomer, double cast) {
        double delkaHrany;
        delkaHrany = vypocetiDelkuHrany(pocetHran, polomer);
        nakresliPravidelnyNUhlenik(pocetHran, delkaHrany, cast);
    }

    public double vypocetiDelkuHrany(int pocetHran, double polomer) {
        double uhel;
        uhel = (360.00 / pocetHran) / 2;
        double vysledek;
        vysledek = 2 * (polomer * Math.sin(Math.toRadians(uhel)));
        return vysledek;
    }

    public void nakresliRovnoramennyTrojuhelnik(double delkaRamene, double sevrenyUhel) {
        zofka.turnRight(90);
        double zakladnaTrojuhelniku;
        zakladnaTrojuhelniku = vypoctiZakladnuTrojuhelniku(delkaRamene, sevrenyUhel);
        zofka.move(zakladnaTrojuhelniku);
        zofka.turnRight(90 + sevrenyUhel / 2);
        zofka.move(delkaRamene);
        zofka.turnRight(180 - sevrenyUhel);
        zofka.move(delkaRamene);
        zofka.turnRight(sevrenyUhel / 2);
    }

    public double vypoctiZakladnuTrojuhelniku(double delkaRamene, double sevrenyUhel) {
        double vysledek;
        vysledek = 2 * (delkaRamene * Math.sin(Math.toRadians(sevrenyUhel / 2)));
        return vysledek;
    }

    public void jedVlevo(double oKolik) {
        zofka.penUp();
        zofka.turnLeft(90);
        zofka.move(oKolik);
        zofka.turnRight(90);
        zofka.penDown();
    }

    public void jedVpravo(double oKolik) {
        zofka.penUp();
        zofka.turnRight(90);
        zofka.move(oKolik);
        zofka.turnLeft(90);
        zofka.penDown();
    }

    public void jedNahoru(double oKolik) {
        zofka.penUp();
        zofka.move(oKolik);
        zofka.penDown();
    }

    public void jedDolu(double oKolik) {
        zofka.penUp();
        zofka.turnRight(180);
        zofka.move(oKolik);
        zofka.turnLeft(180);
        zofka.penDown();
    }

}
