package cz.czechitas;

public class SpousteciTrida {

    public static void main(String[] args) {
        Pocitac lenkyPocitac = new Pocitac();
        System.out.println(lenkyPocitac);
        lenkyPocitac.zapniSe();

        Procesor lenkyProcesor = new Procesor();
        lenkyProcesor.setVyrobce("Intel Core");
        lenkyProcesor.setRychlost(1600L * 1000L * 1000L);
        lenkyPocitac.setCpu(lenkyProcesor);

        Pamet lenkyPamet = new Pamet();
        lenkyPamet.setKapacita(8L * 1024L * 1024L * 1024L);
        lenkyPocitac.setRam(lenkyPamet);

        lenkyPocitac.zapniSe();

        Disk lenkyDisk = new Disk();
        lenkyDisk.setKapacita(500L * 1024L * 1024L * 1024L);
        lenkyPocitac.setPevnyDisk(lenkyDisk);

        Disk lenkyDruhyDisk = new Disk();
        lenkyDruhyDisk.setKapacita(300L * 1024L * 1024L * 1024L);
        lenkyPocitac.setDruhyDisk(lenkyDruhyDisk);

        System.out.println(lenkyPocitac);

        lenkyPocitac.zapniSe();
        lenkyPocitac.zapniSe();

        lenkyPocitac.vytvorSouborOVelikosti(400L * 1024L * 1024L * 1024L);
        System.out.println(lenkyPocitac.getPevnyDisk().getVyuziteMisto());
        System.out.println(lenkyPocitac.getDruhyDisk().getVyuziteMisto());
        lenkyPocitac.vytvorSouborOVelikosti(300L * 1024L * 1024L * 1024L);
        System.out.println(lenkyPocitac.getPevnyDisk().getVyuziteMisto());
        System.out.println(lenkyPocitac.getDruhyDisk().getVyuziteMisto());
        lenkyPocitac.vytvorSouborOVelikosti(600L * 1024L * 1024L * 1024L);
        System.out.println(lenkyPocitac.getPevnyDisk().getVyuziteMisto());
        System.out.println(lenkyPocitac.getDruhyDisk().getVyuziteMisto());
        lenkyPocitac.vytvorSouborOVelikosti(100L * 1024L * 1024L * 1024L);
        System.out.println(lenkyPocitac.getPevnyDisk().getVyuziteMisto());
        System.out.println(lenkyPocitac.getDruhyDisk().getVyuziteMisto());

        lenkyPocitac.vypniSe();

        lenkyPocitac.vymazSouboryOVelikosti(10L * 1024L * 1024L * 1024L);

        lenkyPocitac.zapniSe();
        lenkyPocitac.vymazSouboryOVelikosti(10L * 1024L * 1024L * 1024L);
        System.out.println(lenkyPocitac.getPevnyDisk().getVyuziteMisto());
        System.out.println(lenkyPocitac.getDruhyDisk().getVyuziteMisto());
        lenkyPocitac.vymazSouboryOVelikosti(900L * 1024L * 1024L * 1024L);
        System.out.println(lenkyPocitac.getPevnyDisk().getVyuziteMisto());
        System.out.println(lenkyPocitac.getDruhyDisk().getVyuziteMisto());
        lenkyPocitac.vymazSouboryOVelikosti(500L * 1024L * 1024L * 1024L);
        System.out.println(lenkyPocitac.getPevnyDisk().getVyuziteMisto());
        System.out.println(lenkyPocitac.getDruhyDisk().getVyuziteMisto());

        lenkyPocitac.vypniSe();
        lenkyPocitac.vypniSe();
    }

}
