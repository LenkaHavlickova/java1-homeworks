package cz.czechitas;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import net.miginfocom.swing.*;

public class HlavniOkno extends JFrame {

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    // Generated using JFormDesigner non-commercial license
    JLabel label4;
    JLabel label5;
    JButton button1;
    JLabel label6;
    JTextField textFieldHusyPocetSamic;
    JLabel label8;
    JTextField textFieldKraliciPocetSamic;
    JLabel labelPocetHlav;
    JTextField textFieldPocetHlav;
    JLabel label7;
    JTextField textFieldHusyPocetSamcu;
    JLabel label9;
    JTextField textFieldKraliciPocetSamcu;
    JLabel labelPocetNohou;
    JTextField textFieldPocetNohou;
    JButton button2;
    JLabel label10;
    JLabel labelPocetHus;
    JTextField textFieldPocetHus;
    JLabel labelPocetKraliku;
    JTextField textFieldPocetKraliku;
    JLabel label11;
    JLabel label13;
    JTextField textFieldHmotnostPsenice;
    JLabel label16;
    JLabel label14;
    JTextField textFieldHmotnostMrkve;
    JLabel label17;
    JLabel label12;
    JTextField textFieldPocetRadkuPsenice;
    JLabel label15;
    JTextField textFieldPocetRadkuMrkve;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
    JPanel contentPane;
    MigLayout migLayoutManager;

    public HlavniOkno() {
        initComponents();
    }

    private void priStiskuTlacitkaVypoctiHlavyNohy(ActionEvent e) {
        String pocetHusSamicText = textFieldHusyPocetSamic.getText();
        int pocetHusSamic = Integer.parseInt(pocetHusSamicText);
        String pocetHusSamcuText = textFieldHusyPocetSamcu.getText();
        int pocetHusSamcu = Integer.parseInt(pocetHusSamcuText);

        String pocetKralikSamiceText = textFieldKraliciPocetSamic.getText();
        int pocetKralikuSamic = Integer.parseInt(pocetKralikSamiceText);
        String pocetKralikSamecText = textFieldKraliciPocetSamcu.getText();
        int pocetKralikSamcu = Integer.parseInt(pocetKralikSamecText);

        int pocetHus = pocetHusSamcu + pocetHusSamic;
        int pocetKraliku = pocetKralikuSamic + pocetKralikSamcu;
        
        int pocetHlav = pocetHus + pocetKraliku;
        String pocetHlavText = Integer.toString(pocetHlav);
        textFieldPocetHlav.setText(pocetHlavText);
        int pocetNohou = pocetHus * 2 + pocetKraliku * 4;
        String pocetNohouText = Integer.toString(pocetNohou);
        textFieldPocetNohou.setText(pocetNohouText);

    }

    private void priStiskuTlacitkaVypoctiZvirataPotraviny(ActionEvent e) {
        String pocetHusSamicText = textFieldHusyPocetSamic.getText();
        int pocetHusSamic = Integer.parseInt(pocetHusSamicText);
        String pocetHusSamcuText = textFieldHusyPocetSamcu.getText();
        int pocetHusSamcu = Integer.parseInt(pocetHusSamcuText);

        String pocetKralikSamiceText = textFieldKraliciPocetSamic.getText();
        int pocetKralikuSamic = Integer.parseInt(pocetKralikSamiceText);
        String pocetKralikSamecText = textFieldKraliciPocetSamcu.getText();
        int pocetKralikSamcu = Integer.parseInt(pocetKralikSamecText);

        int pocetHus;
        if (pocetHusSamcu!=0 && pocetHusSamic!=0) {
            pocetHus = pocetHusSamic * 15 + pocetHusSamcu + pocetHusSamic;
        } else {
            pocetHus = pocetHusSamic + pocetHusSamcu;
        }

        String pocetHusText = Integer.toString(pocetHus);
        textFieldPocetHus.setText(pocetHusText);

        double pseniceHmotnost = pocetHus * 183 * 0.25;
        String pseniceHmotnostText = Double.toString(pseniceHmotnost);
        textFieldHmotnostPsenice.setText(pseniceHmotnostText);

        int pocetRadkuPsenice = (int) Math.round(Math.ceil(pseniceHmotnost / 2));
        String pocetRadkuPseniceText = Integer.toString(pocetRadkuPsenice);
        textFieldPocetRadkuPsenice.setText(pocetRadkuPseniceText);
        

        int pocetKraliku;
        if (pocetKralikSamcu != 0 && pocetKralikuSamic != 0) {
            pocetKraliku = pocetKralikuSamic * 40 + pocetKralikSamcu + pocetKralikuSamic;
        }   else {
            pocetKraliku = pocetKralikuSamic + pocetKralikSamcu;
        }

        String pocetKralikuText = Integer.toString(pocetKraliku);
        textFieldPocetKraliku.setText(pocetKralikuText);

        double mrkevHmotnost = pocetKraliku * 0.5 * 183;
        String mrkevHmostnostText = Double.toString(mrkevHmotnost);
        textFieldHmotnostMrkve.setText(mrkevHmostnostText);

        int pocetRadkuMrkve = (int) Math.round(Math.ceil(mrkevHmotnost / 5));
        String pocetRadkuMrkveText = Integer.toString(pocetRadkuMrkve);
        textFieldPocetRadkuMrkve.setText(pocetRadkuMrkveText);

        
    }



    private void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        // Generated using JFormDesigner non-commercial license
        label4 = new JLabel();
        label5 = new JLabel();
        button1 = new JButton();
        label6 = new JLabel();
        textFieldHusyPocetSamic = new JTextField();
        label8 = new JLabel();
        textFieldKraliciPocetSamic = new JTextField();
        labelPocetHlav = new JLabel();
        textFieldPocetHlav = new JTextField();
        label7 = new JLabel();
        textFieldHusyPocetSamcu = new JTextField();
        label9 = new JLabel();
        textFieldKraliciPocetSamcu = new JTextField();
        labelPocetNohou = new JLabel();
        textFieldPocetNohou = new JTextField();
        button2 = new JButton();
        label10 = new JLabel();
        labelPocetHus = new JLabel();
        textFieldPocetHus = new JTextField();
        labelPocetKraliku = new JLabel();
        textFieldPocetKraliku = new JTextField();
        label11 = new JLabel();
        label13 = new JLabel();
        textFieldHmotnostPsenice = new JTextField();
        label16 = new JLabel();
        label14 = new JLabel();
        textFieldHmotnostMrkve = new JTextField();
        label17 = new JLabel();
        label12 = new JLabel();
        textFieldPocetRadkuPsenice = new JTextField();
        label15 = new JLabel();
        textFieldPocetRadkuMrkve = new JTextField();

        //======== this ========
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("FARMA");
        Container contentPane = getContentPane();
        contentPane.setLayout(new MigLayout(
            "insets rel,hidemode 3",
            // columns
            "[fill]" +
            "[grow,fill]" +
            "[fill]" +
            "[grow,fill]" +
            "[78,grow,fill]" +
            "[grow,fill]" +
            "[70,grow,fill]" +
            "[grow,fill]" +
            "[fill]" +
            "[fill]" +
            "[grow,fill]" +
            "[grow,fill]" +
            "[fill]" +
            "[fill]" +
            "[fill]" +
            "[fill]" +
            "[fill]" +
            "[fill]" +
            "[fill]" +
            "[fill]",
            // rows
            "[]" +
            "[fill]" +
            "[]" +
            "[]" +
            "[]" +
            "[]" +
            "[]" +
            "[]" +
            "[]" +
            "[]" +
            "[grow]"));
        this.contentPane = (JPanel) this.getContentPane();
        this.contentPane.setBackground(this.getBackground());
        LayoutManager layout = this.contentPane.getLayout();
        if (layout instanceof MigLayout) {
            this.migLayoutManager = (MigLayout) layout;
        }

        //---- label4 ----
        label4.setText("Husy");
        label4.setHorizontalAlignment(SwingConstants.CENTER);
        label4.setFont(new Font("Segoe UI", Font.BOLD, 14));
        contentPane.add(label4, "cell 1 1 3 1");

        //---- label5 ----
        label5.setText("Kr\u00e1l\u00edci");
        label5.setHorizontalAlignment(SwingConstants.CENTER);
        label5.setFont(new Font("Segoe UI", Font.BOLD, 14));
        contentPane.add(label5, "cell 5 1 2 1");

        //---- button1 ----
        button1.setText("Vypo\u010dti hlavy a nohy");
        button1.addActionListener(e -> priStiskuTlacitkaVypoctiHlavyNohy(e));
        contentPane.add(button1, "cell 10 1 2 1");

        //---- label6 ----
        label6.setText("Po\u010det samic:");
        contentPane.add(label6, "cell 1 2");
        contentPane.add(textFieldHusyPocetSamic, "cell 3 2");

        //---- label8 ----
        label8.setText("Po\u010det samic:");
        contentPane.add(label8, "cell 5 2");
        contentPane.add(textFieldKraliciPocetSamic, "cell 6 2");

        //---- labelPocetHlav ----
        labelPocetHlav.setText("Akut\u00e1ln\u00ed po\u010det hlav:");
        contentPane.add(labelPocetHlav, "cell 10 2");

        //---- textFieldPocetHlav ----
        textFieldPocetHlav.setColumns(7);
        textFieldPocetHlav.setEditable(false);
        contentPane.add(textFieldPocetHlav, "cell 11 2");

        //---- label7 ----
        label7.setText("Po\u010det samc\u016f:");
        contentPane.add(label7, "cell 1 3");
        contentPane.add(textFieldHusyPocetSamcu, "cell 3 3");

        //---- label9 ----
        label9.setText("Po\u010det samc\u016f:");
        contentPane.add(label9, "cell 5 3");
        contentPane.add(textFieldKraliciPocetSamcu, "cell 6 3");

        //---- labelPocetNohou ----
        labelPocetNohou.setText("Aktu\u00e1ln\u00ed po\u010det nohou:");
        contentPane.add(labelPocetNohou, "cell 10 3");

        //---- textFieldPocetNohou ----
        textFieldPocetNohou.setColumns(7);
        textFieldPocetNohou.setEditable(false);
        contentPane.add(textFieldPocetNohou, "cell 11 3");

        //---- button2 ----
        button2.setText("Vypo\u010dti po\u010det zv\u00ed\u0159at a potravy");
        button2.addActionListener(e -> priStiskuTlacitkaVypoctiZvirataPotraviny(e));
        contentPane.add(button2, "cell 3 4 3 1");

        //---- label10 ----
        label10.setText("Celkov\u00fd po\u010det hus a kr\u00e1l\u00edk\u016f po sez\u00f3n\u011b p\u0159ed zimou");
        label10.setFont(new Font("Segoe UI", Font.BOLD, 12));
        label10.setHorizontalAlignment(SwingConstants.CENTER);
        contentPane.add(label10, "cell 1 5 6 1");

        //---- labelPocetHus ----
        labelPocetHus.setText("Po\u010det hus:");
        contentPane.add(labelPocetHus, "cell 1 6");

        //---- textFieldPocetHus ----
        textFieldPocetHus.setColumns(7);
        textFieldPocetHus.setEditable(false);
        contentPane.add(textFieldPocetHus, "cell 3 6");

        //---- labelPocetKraliku ----
        labelPocetKraliku.setText("Po\u010det kr\u00e1l\u00edk\u016f:");
        contentPane.add(labelPocetKraliku, "cell 5 6");

        //---- textFieldPocetKraliku ----
        textFieldPocetKraliku.setColumns(7);
        textFieldPocetKraliku.setEditable(false);
        contentPane.add(textFieldPocetKraliku, "cell 6 6");

        //---- label11 ----
        label11.setText("Pot\u0159ebn\u00e9 potraviny");
        label11.setFont(new Font("Segoe UI", Font.BOLD, 12));
        label11.setHorizontalAlignment(SwingConstants.CENTER);
        contentPane.add(label11, "cell 1 7 6 1");

        //---- label13 ----
        label13.setText("Hmotnost p\u0161enice:");
        contentPane.add(label13, "cell 1 8");

        //---- textFieldHmotnostPsenice ----
        textFieldHmotnostPsenice.setEditable(false);
        contentPane.add(textFieldHmotnostPsenice, "cell 3 8");

        //---- label16 ----
        label16.setText("kg");
        contentPane.add(label16, "cell 4 8");

        //---- label14 ----
        label14.setText("Hmotnost mrkve:");
        contentPane.add(label14, "cell 5 8");

        //---- textFieldHmotnostMrkve ----
        textFieldHmotnostMrkve.setEditable(false);
        contentPane.add(textFieldHmotnostMrkve, "cell 6 8");

        //---- label17 ----
        label17.setText("kg");
        contentPane.add(label17, "cell 7 8");

        //---- label12 ----
        label12.setText("Po\u010det \u0159\u00e1dk\u016f p\u0161enice:");
        contentPane.add(label12, "cell 1 9");

        //---- textFieldPocetRadkuPsenice ----
        textFieldPocetRadkuPsenice.setEditable(false);
        contentPane.add(textFieldPocetRadkuPsenice, "cell 3 9");

        //---- label15 ----
        label15.setText("Po\u010det \u0159\u00e1dk\u016f mrkve:");
        contentPane.add(label15, "cell 5 9");

        //---- textFieldPocetRadkuMrkve ----
        textFieldPocetRadkuMrkve.setEditable(false);
        contentPane.add(textFieldPocetRadkuMrkve, "cell 6 9");
        pack();
        setLocationRelativeTo(null);
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }
}
