package cz.czechitas;

public class Datum {

    private int rok;
    private int mesic;
    private int den;

    public int getRok() {
        return rok;
    }

    public void setRok(int newValue) {
        rok = newValue;
    }

    public int getMesic() {
        return mesic;
    }

    public void setMesic(int newValue) {
        if (newValue >= 1 && newValue <= 12) {
            if (den >= 0 && den <= 28) {
                mesic = newValue;
            } else if (den == 29 && newValue == 2 && rok != 0 && prestupnyRok(rok)) {
                mesic = newValue;
            } else if (den >= 29 && den <= 30 && newValue != 2) {
                mesic = newValue;
            } else if (den == 31 && dlouhyMesic(newValue)) {
                mesic = newValue;
            } else {
                System.out.println("Neplatna hodnota mesice " + newValue);
            }
        } else {
            System.out.println("Neplatna hodnota mesice " + newValue);
        }
    }

    public int getDen() {
        return den;
    }

    public void setDen(int newValue) {
        if (newValue >= 1 && newValue <= 31) {
            if (mesic == 0) {
                den = newValue;
            } else if (mesic == 2 && newValue <= 28) {
                den = newValue;
            } else if (mesic == 2 && newValue == 29 && rok != 0 && prestupnyRok(rok)) {
                den = newValue;
            } else if (!dlouhyMesic(mesic) && mesic != 2 && newValue <= 30) {
                den = newValue;
            } else if (dlouhyMesic(mesic)) {
                den = newValue;
            } else {
                System.out.println("Neplatna hodnota dne " + newValue);
            }
        } else {
            System.out.println("Neplatna hodnota dne " + newValue);
        }
    }

    public boolean dlouhyMesic(int testMesic) {
        if (testMesic == 1 || testMesic == 3 || testMesic == 5 || testMesic == 7 || testMesic == 8 || testMesic == 10 || testMesic == 12) {
            return true;
        }
        return false;
    }

    @Override
    public String toString() {
        return "Datum " + den + ". " + this.getNazevMesice(mesic) + " " + rok;

    }

    public String getNazevMesice(int mesic) {
        String nazev = "";
        if (mesic == 1) {
            nazev = "leden";
        }
        if (mesic == 2) {
            nazev = "unor";
        }
        if (mesic == 3) {
            nazev = "brezen";
        }
        if (mesic == 4) {
            nazev = "duben";
        }
        if (mesic == 5) {
            nazev = "kveten";
        }
        if (mesic == 6) {
            nazev = "cerven";
        }
        if (mesic == 7) {
            nazev = "cervenec";
        }
        if (mesic == 8) {
            nazev = "srpen";
        }
        if (mesic == 9) {
            nazev = "zari";
        }
        if (mesic == 10) {
            nazev = "rijen";
        }
        if (mesic == 11) {
            nazev = "listopad";
        }
        if (mesic == 12) {
            nazev = "prosinec";
        }

        if (mesic == 0) {
            nazev = " \"Neplatna hodnota mesice\" ";
        }
        return nazev;
    }

    public boolean prestupnyRok(int testRok) {
        if (testRok % 4 == 0 && testRok % 100 != 0) {
            return true;
        } else if (testRok % 4 == 0 && testRok % 100 == 0 && testRok % 400 == 0) {
            return true;
        } else {
            return false;
        }
    }
}
