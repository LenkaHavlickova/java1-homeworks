package cz.czechitas;

public class Pamet {

    private long kapacita;

    public long getKapacita() {
        return kapacita;
    }

    public void setKapacita(long newValue) {
        kapacita = newValue;
    }

    @Override
    public String toString() {
        return "Pamet " +
                "kapacita=" + kapacita;
    }
}
