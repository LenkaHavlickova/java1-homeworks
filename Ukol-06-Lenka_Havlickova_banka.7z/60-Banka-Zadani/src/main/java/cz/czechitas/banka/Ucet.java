package cz.czechitas.banka;

public class Ucet {
    protected double zustatek;
    protected double limitPrecerpani;

    public double getZustatek() {
        return zustatek;
    }

    public double getLimitPrecerpani() {
        return limitPrecerpani;
    }

    public double getPouzitelnyZustatek() {
        return zustatek + limitPrecerpani;
    }

    public boolean vlozPenize (double castka){
        if (castka > 0) {
            zustatek = zustatek + castka;
            return true;
        } else {
            System.out.println("Neni mozne vlozit zapornou nebo nulovou castku!");
            return false;
        }
    }

    public boolean vyberPenize(double castka) {
        if (castka > 0 && zustatek + limitPrecerpani >= castka) {
            zustatek = zustatek - castka;
            return true;
        } else if (castka > 0 && zustatek + limitPrecerpani < castka) {
            return false;
        } else {
            System.out.println("Neni mozne vybrat zapornou nebo nulovou castku!");
            return false;
        }
    }
}
