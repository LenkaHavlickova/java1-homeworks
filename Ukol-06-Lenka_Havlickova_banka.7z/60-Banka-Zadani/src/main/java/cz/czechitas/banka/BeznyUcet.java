package cz.czechitas.banka;

import com.sun.xml.internal.bind.v2.*;

public class BeznyUcet extends Ucet {

    public BeznyUcet(double pocatecniCastka) {
        zustatek = pocatecniCastka;
    }

    public BeznyUcet(double pocatecniCastka, double pocatecniLimitPrecerpani) {
        zustatek = pocatecniCastka;
        limitPrecerpani = pocatecniLimitPrecerpani;
    }

 }
