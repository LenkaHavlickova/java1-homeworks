package cz.czechitas;

import java.util.*;
import java.util.stream.*;

public class Pocitac {

    private boolean jeZapnuty;
    private Procesor cpu;
    private Pamet ram;
    private Disk pevnyDisk;
    private Disk druhyDisk;

    public Disk getDruhyDisk() {
        return druhyDisk;
    }

    public void setDruhyDisk(Disk newValue) {
        druhyDisk = newValue;
    }

    public Procesor getCpu() {
        return cpu;
    }

    public void setCpu(Procesor newValue) {
        cpu = newValue;
    }

    public Pamet getRam() {
        return ram;
    }

    public void setRam(Pamet newValue) {
        ram = newValue;
    }

    public Disk getPevnyDisk() {
        return pevnyDisk;
    }

    public void setPevnyDisk(Disk newValue) {
        pevnyDisk = newValue;
    }

    @Override
    public String toString() {
        return "Pocitac " +
                "jeZapnuty=" + jeZapnuty + ", " +
                "cpu=" + cpu + ", " +
                "ram=" + ram + ", " +
                "pevnyDisk=" + pevnyDisk + ", " +
                "druhyDisk=" + druhyDisk;
    }

    public void zapniSe() {
        if (!jeZapnuty && cpu != null && cpu.getRychlost() != 0 && cpu.getVyrobce() != null && ram != null && pevnyDisk != null) {
            jeZapnuty = true;
            System.out.println("Pocitac byl uspesne zapnut");
        } else {
            if (jeZapnuty) {
                System.out.println("Pocitac nelze zapnout, nebot je jiz zapnuty.");
            } else {
                System.out.println("Pocitac nelze zapnout, nebot mu chybi:");
                if (cpu == null) {
                    System.out.println("procesor");
                }
                ;
                if (cpu != null && cpu.getVyrobce() == null) {
                    System.out.println("vyrobce procesoru");
                }
                ;
                if (cpu != null && cpu.getRychlost() == 0) {
                    System.out.println("rychlost procesoru");
                }
                ;
                if (ram == null) {
                    System.out.println("pamet");
                }
                ;
                if (pevnyDisk == null) {
                    System.out.println("disk");
                }
                ;

            }
        }
    }

    public void vypniSe() {
        if (jeZapnuty) {
            jeZapnuty = false;
            System.out.println("Pocitac byl uspesne vypnut.");
        }
    }

    public void vytvorSouborOVelikosti(long velikost) {
        long volneMisto = pevnyDisk.getKapacita() - pevnyDisk.getVyuziteMisto();
        long volneMistoDruhehoDisku = druhyDisk.getKapacita() - druhyDisk.getVyuziteMisto();
        if (jeZapnuty) {
            if (velikost <= volneMisto) {
                pevnyDisk.setVyuziteMisto(pevnyDisk.getVyuziteMisto() + velikost);
                System.out.println("Soubor o velikosti " + velikost + " byl uspesne vytvoren na prvnim disku.");
            } else if (volneMisto != 0 && velikost <= volneMisto + volneMistoDruhehoDisku) {
                pevnyDisk.setVyuziteMisto(pevnyDisk.getVyuziteMisto() + volneMisto);
                long castSouboruKUlozeniNaDruhyDisk = velikost - volneMisto;
                druhyDisk.setVyuziteMisto(druhyDisk.getVyuziteMisto() + castSouboruKUlozeniNaDruhyDisk);
                System.out.println("Soubor o velikosti " + velikost + " byl uspesne vytvoren " +
                        "castecne na prvnim a castecne na druhem disku.");
            } else if (volneMisto == 0 && velikost <= volneMistoDruhehoDisku) {
                druhyDisk.setVyuziteMisto(druhyDisk.getVyuziteMisto() + velikost);
                System.out.println("Soubor o velikosti " + velikost + " byl uspesne vytvoren na druhem disku.");
            } else {
                System.out.println("Soubor o velikosti " + velikost + " nelze vytvorit, nebot na disku neni dost mista.");
            }
        } else {
            System.out.println("Soubor nelze vytvorit, nebot pocitac neni zapnuty.");
        }
    }

    public void vymazSouboryOVelikosti(long velikost) {
        if (jeZapnuty) {
            if (druhyDisk.getVyuziteMisto() >= velikost) {
                druhyDisk.setVyuziteMisto(druhyDisk.getVyuziteMisto() - velikost);
                System.out.println("Soubor o velikosti " + velikost + " byl vymazan z druheho disku.");
            } else if (druhyDisk.getVyuziteMisto() != 0 && druhyDisk.getVyuziteMisto() + pevnyDisk.getVyuziteMisto() >= velikost) {
                long castSouboruKeSmazaniZPrvnihoDisku = velikost - druhyDisk.getVyuziteMisto();
                pevnyDisk.setVyuziteMisto(pevnyDisk.getVyuziteMisto() - castSouboruKeSmazaniZPrvnihoDisku);
                druhyDisk.setVyuziteMisto(0);
                System.out.println("Soubor o velikosti " + velikost + " byl vymazan z castecne z prvniho a castecne z druheho disku.");
            } else if (druhyDisk.getVyuziteMisto() == 0 && velikost <= pevnyDisk.getVyuziteMisto()) {
                pevnyDisk.setVyuziteMisto(pevnyDisk.getVyuziteMisto() - velikost);
                System.out.println("Soubor o velikosti " + velikost + " byl vymazan z prvniho disku.");
            } else {
                System.out.println("Soubor o velikosti " + velikost + " nelze vymazat, nebot na disku neni dostatecna vyuzita kapacita.");
            }

        } else {
            System.out.println("Soubor nelze vymazat, nebot pocitac neni zapnuty.");
        }

    }
}
