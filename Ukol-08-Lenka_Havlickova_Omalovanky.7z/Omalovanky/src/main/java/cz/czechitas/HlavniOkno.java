package cz.czechitas;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.io.*;
import java.util.*;
import javax.imageio.*;
import javax.swing.*;
import javax.swing.filechooser.*;
import net.miginfocom.swing.*;
import net.sevecek.util.*;

public class HlavniOkno extends JFrame {

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    // Generated using JFormDesigner non-commercial license
    JMenuBar menuBar1;
    JMenu menSoubor;
    JMenuItem menIOtevrit;
    JMenuItem menIUlozit;
    JMenuItem menIUlozitJako;
    JMenuItem menIUkoncit;
    JLabel labNadpis;
    JLabel labBarva1;
    JLabel labBarva2;
    JLabel labBarva3;
    JLabel labBarva4;
    JLabel labBarva5;
    JLabel labObrazek;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
    JPanel contentPane;
    MigLayout migLayoutManager;
    BufferedImage obrazek;
    Color zvolenaBarva;
    File otevrenySoubor;

    public HlavniOkno() {
        initComponents();
    }

    private void priOtevreniOkna(WindowEvent e) {
        File soubor = new File ("obrazek1.png");
        nahrajObrazek(soubor);
        otevrenySoubor = soubor;
    }

    private void nahrajObrazek(File soubor) {
        try {
            obrazek = ImageIO.read(soubor);
        } catch (IOException ex) {
            throw new ApplicationPublicException(ex, "Nepodařilo se nahrát obrázek mandaly ze souboru " + soubor.getAbsolutePath());
        }
        labObrazek.setIcon(new ImageIcon(obrazek));
        labObrazek.setMinimumSize(new Dimension(obrazek.getWidth(), obrazek.getHeight()));
        pack();
        setMinimumSize(getSize());
    }


    /**
     * Vyplni <code>BufferedImage obrazek</code>
     * na pozicich <code>int x</code>, <code>int y</code>
     * barvou <code>Color barva</code>
     */
    public void vyplnObrazek(BufferedImage obrazek, int x, int y, Color barva) {
        if (barva == null) {
            barva = new Color(255, 255, 0);
        }

        // Zamez vyplnovani mimo rozsah
        if (x < 0 || x >= obrazek.getWidth() || y < 0 || y >= obrazek.getHeight()) {
            return;
        }

        WritableRaster pixely = obrazek.getRaster();
        int[] novyPixel = new int[] {barva.getRed(), barva.getGreen(), barva.getBlue(), barva.getAlpha()};
        int[] staryPixel = new int[] {255, 255, 255, 255};
        staryPixel = pixely.getPixel(x, y, staryPixel);

        // Pokud uz je pocatecni pixel obarven na cilovou barvu, nic nemen
        if (pixelyMajiStejnouBarvu(novyPixel, staryPixel)) {
            return;
        }

        // Zamez prebarveni cerne cary
        int[] cernyPixel = new int[] {0, 0, 0, staryPixel[3]};
        if (pixelyMajiStejnouBarvu(cernyPixel, staryPixel)) {
            return;
        }

        vyplnovaciSmycka(pixely, x, y, novyPixel, staryPixel);
    }

    /**
     * Provede skutecne vyplneni pomoci zasobniku
     */
    private void vyplnovaciSmycka(WritableRaster raster, int x, int y, int[] novaBarva, int[] nahrazovanaBarva) {
        Rectangle rozmery = raster.getBounds();
        int[] aktualniBarva = new int[] {255, 255, 255, 255};

        Deque<Point> zasobnik = new ArrayDeque<>(rozmery.width * rozmery.height);
        zasobnik.push(new Point(x, y));
        while (zasobnik.size() > 0) {
            Point point = zasobnik.pop();
            x = point.x;
            y = point.y;
            if (!pixelyMajiStejnouBarvu(raster.getPixel(x, y, aktualniBarva), nahrazovanaBarva)) {
                continue;
            }

            // Najdi levou zed, po ceste vyplnuj
            int levaZed = x;
            do {
                raster.setPixel(levaZed, y, novaBarva);
                levaZed--;
            }
            while (levaZed >= 0 && pixelyMajiStejnouBarvu(raster.getPixel(levaZed, y, aktualniBarva), nahrazovanaBarva));
            levaZed++;

            // Najdi pravou zed, po ceste vyplnuj
            int pravaZed = x;
            do {
                raster.setPixel(pravaZed, y, novaBarva);
                pravaZed++;
            }
            while (pravaZed < rozmery.width && pixelyMajiStejnouBarvu(raster.getPixel(pravaZed, y, aktualniBarva), nahrazovanaBarva));
            pravaZed--;

            // Pridej na zasobnik body nahore a dole
            for (int i = levaZed; i <= pravaZed; i++) {
                if (y > 0 && pixelyMajiStejnouBarvu(raster.getPixel(i, y - 1, aktualniBarva), nahrazovanaBarva)) {
                    if (!(i > levaZed && i < pravaZed
                            && pixelyMajiStejnouBarvu(raster.getPixel(i - 1, y - 1, aktualniBarva), nahrazovanaBarva)
                            && pixelyMajiStejnouBarvu(raster.getPixel(i + 1, y - 1, aktualniBarva), nahrazovanaBarva))) {
                        zasobnik.add(new Point(i, y - 1));
                    }
                }
                if (y < rozmery.height - 1 && pixelyMajiStejnouBarvu(raster.getPixel(i, y + 1, aktualniBarva), nahrazovanaBarva)) {
                    if (!(i > levaZed && i < pravaZed
                            && pixelyMajiStejnouBarvu(raster.getPixel(i - 1, y + 1, aktualniBarva), nahrazovanaBarva)
                            && pixelyMajiStejnouBarvu(raster.getPixel(i + 1, y + 1, aktualniBarva), nahrazovanaBarva))) {
                        zasobnik.add(new Point(i, y + 1));
                    }
                }
            }
        }
    }

    /**
     * Vrati true pokud RGB hodnoty v polich jsou stejne. Pokud jsou ruzne, vraci false
     */
    private boolean pixelyMajiStejnouBarvu(int[] barva1, int[] barva2) {
        return barva1[0] == barva2[0] && barva1[1] == barva2[1] && barva1[2] == barva2[2];
    }

    private void priKliknutiMysi(MouseEvent e) {
        int x = e.getX();
        int y = e.getY();
        vyplnObrazek(obrazek, x, y, zvolenaBarva);
        labObrazek.repaint();
    }

    private void priKliknutiNaLabBarva(MouseEvent e) {
        labBarva1.setText("");
        labBarva2.setText("");
        labBarva3.setText("");
        labBarva4.setText("");
        labBarva5.setText("");
        JLabel tlacitkoBarva = (JLabel) e.getSource();
        zvolenaBarva = tlacitkoBarva.getBackground();
        tlacitkoBarva.setText("X");

    }


    private void priStiskuUkoncit(ActionEvent e) {
        dispose();
    }

    private void priStiskuOtevrit(ActionEvent e) {
        JFileChooser dialog;
        if (otevrenySoubor == null) {
            dialog = new JFileChooser(".");
        } else {
            dialog = new JFileChooser(otevrenySoubor.getParentFile());
        }
        dialog.setFileSelectionMode(JFileChooser.FILES_ONLY);
        dialog.setMultiSelectionEnabled(false);
        dialog.addChoosableFileFilter(new FileNameExtensionFilter("Obrázky (*.png)", "png"));
        int vysledek = dialog.showOpenDialog(this);
        if (vysledek != JFileChooser.APPROVE_OPTION) {
            return;
        }

        otevrenySoubor = dialog.getSelectedFile();
        nahrajObrazek(otevrenySoubor);
    }

    private void priStisknutiUlozit(ActionEvent e) {
        ulozObrazek(otevrenySoubor);
    }

    private void ulozObrazek(File soubor) {
        try {
            ImageIO.write(obrazek, "png", soubor);
        } catch (IOException ex) {
            throw new ApplicationPublicException(ex, "Nepodařilo se uložit obrázek mandaly do souboru " + soubor.getAbsolutePath());
        }

    }

    private void ulozitJako() {
        JFileChooser dialog;
        dialog = new JFileChooser(".");

        int vysledek = dialog.showSaveDialog(this);
        if (vysledek != JFileChooser.APPROVE_OPTION) {
            return;
        }

        File soubor = dialog.getSelectedFile();
        if (!soubor.getName().contains(".") && !soubor.exists()) {
            soubor = new File(soubor.getParentFile(), soubor.getName() + ".png");
        }
        if (soubor.exists()) {
            int potvrzeni = JOptionPane.showConfirmDialog(this, "Soubor " + soubor.getName() + " už existuje.\nChcete jej přepsat?", "Přepsat soubor?", JOptionPane.YES_NO_OPTION);
            if (potvrzeni == JOptionPane.NO_OPTION) {
                return;
            }
        }
        ulozObrazek(soubor);
    }

    private void priStiskuUlozitJako(ActionEvent e) {
        ulozitJako();
    }

    private void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        // Generated using JFormDesigner non-commercial license
        menuBar1 = new JMenuBar();
        menSoubor = new JMenu();
        menIOtevrit = new JMenuItem();
        menIUlozit = new JMenuItem();
        menIUlozitJako = new JMenuItem();
        menIUkoncit = new JMenuItem();
        labNadpis = new JLabel();
        labBarva1 = new JLabel();
        labBarva2 = new JLabel();
        labBarva3 = new JLabel();
        labBarva4 = new JLabel();
        labBarva5 = new JLabel();
        labObrazek = new JLabel();

        //======== this ========
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Omalovanky");
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowOpened(WindowEvent e) {
                priOtevreniOkna(e);
            }
        });
        Container contentPane = getContentPane();
        contentPane.setLayout(new MigLayout(
            "insets rel,hidemode 3",
            // columns
            "[fill]" +
            "[fill]" +
            "[fill]" +
            "[fill]" +
            "[fill]" +
            "[fill]" +
            "[fill]" +
            "[grow,fill]",
            // rows
            "[fill]" +
            "[grow]"));
        this.contentPane = (JPanel) this.getContentPane();
        this.contentPane.setBackground(this.getBackground());
        LayoutManager layout = this.contentPane.getLayout();
        if (layout instanceof MigLayout) {
            this.migLayoutManager = (MigLayout) layout;
        }

        //======== menuBar1 ========
        {

            //======== menSoubor ========
            {
                menSoubor.setText("Soubor");

                //---- menIOtevrit ----
                menIOtevrit.setText("Otev\u0159\u00edt");
                menIOtevrit.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
                menIOtevrit.addActionListener(e -> priStiskuOtevrit(e));
                menSoubor.add(menIOtevrit);
                menSoubor.addSeparator();

                //---- menIUlozit ----
                menIUlozit.setText("Ulo\u017eit");
                menIUlozit.addActionListener(e -> priStisknutiUlozit(e));
                menSoubor.add(menIUlozit);
                menSoubor.addSeparator();

                //---- menIUlozitJako ----
                menIUlozitJako.setText("Ulo\u017eit jako");
                menIUlozitJako.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
                menIUlozitJako.addActionListener(e -> priStiskuUlozitJako(e));
                menSoubor.add(menIUlozitJako);
                menSoubor.addSeparator();

                //---- menIUkoncit ----
                menIUkoncit.setText("Ukon\u010dit");
                menIUkoncit.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Q, Toolkit.getDefaultToolkit().getMenuShortcutKeyMask()));
                menIUkoncit.addActionListener(e -> priStiskuUkoncit(e));
                menSoubor.add(menIUkoncit);
            }
            menuBar1.add(menSoubor);
        }
        setJMenuBar(menuBar1);

        //---- labNadpis ----
        labNadpis.setText("Aktu\u00e1ln\u00ed barva:");
        labNadpis.setFont(labNadpis.getFont().deriveFont(Font.BOLD|Font.ITALIC, labNadpis.getFont().getSize() + 2f));
        contentPane.add(labNadpis, "cell 1 0");

        //---- labBarva1 ----
        labBarva1.setBackground(new Color(255, 63, 48, 214));
        labBarva1.setOpaque(true);
        labBarva1.setMinimumSize(new Dimension(32, 32));
        labBarva1.setPreferredSize(new Dimension(32, 32));
        labBarva1.setFont(labBarva1.getFont().deriveFont(labBarva1.getFont().getStyle() | Font.BOLD, labBarva1.getFont().getSize() + 11f));
        labBarva1.setHorizontalAlignment(SwingConstants.CENTER);
        labBarva1.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                priKliknutiNaLabBarva(e);
            }
        });
        contentPane.add(labBarva1, "cell 2 0");

        //---- labBarva2 ----
        labBarva2.setBackground(new Color(235, 107, 23));
        labBarva2.setOpaque(true);
        labBarva2.setMinimumSize(new Dimension(32, 32));
        labBarva2.setPreferredSize(new Dimension(32, 32));
        labBarva2.setFont(labBarva2.getFont().deriveFont(labBarva2.getFont().getStyle() | Font.BOLD, labBarva2.getFont().getSize() + 11f));
        labBarva2.setHorizontalAlignment(SwingConstants.CENTER);
        labBarva2.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                priKliknutiNaLabBarva(e);
            }
        });
        contentPane.add(labBarva2, "cell 3 0");

        //---- labBarva3 ----
        labBarva3.setBackground(new Color(255, 187, 41));
        labBarva3.setOpaque(true);
        labBarva3.setMinimumSize(new Dimension(32, 32));
        labBarva3.setPreferredSize(new Dimension(32, 32));
        labBarva3.setFont(labBarva3.getFont().deriveFont(labBarva3.getFont().getStyle() | Font.BOLD, labBarva3.getFont().getSize() + 11f));
        labBarva3.setHorizontalAlignment(SwingConstants.CENTER);
        labBarva3.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                priKliknutiNaLabBarva(e);
            }
        });
        contentPane.add(labBarva3, "cell 4 0");

        //---- labBarva4 ----
        labBarva4.setBackground(new Color(235, 221, 84));
        labBarva4.setOpaque(true);
        labBarva4.setMinimumSize(new Dimension(32, 32));
        labBarva4.setPreferredSize(new Dimension(32, 32));
        labBarva4.setFont(labBarva4.getFont().deriveFont(labBarva4.getFont().getStyle() | Font.BOLD, labBarva4.getFont().getSize() + 11f));
        labBarva4.setHorizontalAlignment(SwingConstants.CENTER);
        labBarva4.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                priKliknutiNaLabBarva(e);
            }
        });
        contentPane.add(labBarva4, "cell 5 0");

        //---- labBarva5 ----
        labBarva5.setBackground(new Color(153, 255, 46));
        labBarva5.setOpaque(true);
        labBarva5.setMinimumSize(new Dimension(32, 32));
        labBarva5.setPreferredSize(new Dimension(32, 32));
        labBarva5.setFont(labBarva5.getFont().deriveFont(labBarva5.getFont().getStyle() | Font.BOLD, labBarva5.getFont().getSize() + 11f));
        labBarva5.setHorizontalAlignment(SwingConstants.CENTER);
        labBarva5.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                priKliknutiNaLabBarva(e);
            }
        });
        contentPane.add(labBarva5, "cell 6 0");

        //---- labObrazek ----
        labObrazek.setBackground(Color.white);
        labObrazek.setOpaque(true);
        labObrazek.setVerticalAlignment(SwingConstants.TOP);
        labObrazek.setHorizontalAlignment(SwingConstants.LEFT);
        labObrazek.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                priKliknutiMysi(e);
            }
        });
        contentPane.add(labObrazek, "cell 1 1 7 1,growy");
        setSize(400, 300);
        setLocationRelativeTo(null);
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }
}
