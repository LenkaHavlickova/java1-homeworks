package cz.czechitas;

public class Disk {

    private long kapacita;
    private long vyuziteMisto;

    public void nahrajSoubor(long velikost) {
        vyuziteMisto = vyuziteMisto + velikost;
    }

    public void vymazSoubor(long velikost) {
        vyuziteMisto = vyuziteMisto - velikost;
    }

    public long getVyuziteMisto() {
        return vyuziteMisto;
    }

    public long getKapacita() {
        return kapacita;
    }

    public void setKapacita(long newValue) {
        kapacita = newValue;
    }

    @Override
    public String toString() {
        return "Disk " +
                "kapacita=" + kapacita + ", " +
                "vyuziteMisto=" + vyuziteMisto;
    }
}
