package net.sevecek.turtle;

import java.awt.*;
import com.sun.org.apache.xalan.internal.xsltc.dom.*;
import net.sevecek.turtle.engine.*;
import sun.font.*;

public class HlavniProgram {

    Turtle zofka;

    public void main(String[] args) {
        zofka = new Turtle();

        jedVlevo();
        jedVlevo();
        jedVlevo();
        jedNahoru();
        jedNahoru();
        nakresliSlunicko();
        jedDolu();
        jedDolu();
        jedVlevo();
        for (int i = 0; i < 5; i++) {
            nakresliDomecek();
            jedVpravo();
            jedVpravo();
        }
        jedDolu();
        jedDolu();
        jedVlevo();
        jedVlevo();
        nakresliDomecek();
        for (int i = 0; i < 8; i++) {
            jedVlevo();
        }
        nakresliDomecek();
        jedVpravo();
        jedVpravo();
        jedVpravo();
        jedVpravo();
        jedVpravo();
        nakresliPrasatko();
    }

    public void nakresliCtverec() {
        for (int i = 0; i < 4; i++) {
            zofka.move(50);
            zofka.turnRight(90);
        }
    }

    public void nakresliTeloPrasatka() {
        nakresliCtverec();
        zofka.move(50);
        zofka.turnRight(30);
        for (int i = 0; i < 3; i++) {
            zofka.move(50);
            zofka.turnRight(120);
        }
        zofka.turnRight(150);
        zofka.move(50);
        zofka.turnRight(180);
    }

    public void nakresliNozicky() {
        zofka.setPenWidth(5);
        zofka.turnLeft(45);
        zofka.move(20);
        zofka.turnRight(180);
        zofka.move(20);
        zofka.turnRight(90);
        zofka.move(20);
        zofka.turnRight(180);
        zofka.move(20);
        zofka.turnLeft(45);
    }

    public void nakresliPrasatko() {
        zofka.setPenColor(Color.PINK);
        zofka.turnLeft(90);
        nakresliTeloPrasatka();
        nakresliNozicky();
        zofka.move(50);
        nakresliNozicky();
        zofka.penUp();
        zofka.turnRight(90);
        zofka.move(50);
        zofka.turnRight(90);
        zofka.move(50);
        zofka.turnLeft(45);
        zofka.penDown();
        for (int i = 0; i < 8; i++) {
            zofka.move(4);
            zofka.turnRight(12);
        }
        for (int i = 0; i < 15; i++) {
            zofka.move(2);
            zofka.turnRight(15);
        }
        for (int i = 0; i < 12; i++) {
            zofka.move(3);
            zofka.turnRight(12);
        }
    }

    public void jedVlevo() {
        zofka.penUp();
        zofka.turnLeft(90);
        zofka.move(75);
        zofka.turnRight(90);
        zofka.penDown();
    }

    public void jedVpravo() {
        zofka.penUp();
        zofka.turnRight(90);
        zofka.move(75);
        zofka.turnLeft(90);
        zofka.penDown();
    }

    public void jedNahoru() {
        zofka.penUp();
        zofka.move(75);
        zofka.penDown();
    }

    public void jedDolu() {
        zofka.penUp();
        zofka.turnRight(180);
        zofka.move(75);
        zofka.turnLeft(180);
        zofka.penDown();
    }

    public void nakresliDomecek() {
        zofka.setPenColor(Color.BLACK);
        nakresliCtverec();
        zofka.move(50);
        zofka.turnRight(30);
        zofka.setPenColor(Color.RED);
        for (int i = 0; i < 3; i++) {
            zofka.move(50);
            zofka.turnRight(120);
        }
        zofka.turnRight(150);
        zofka.penUp();
        zofka.move(50);
        zofka.turnRight(180);
    }

    public void nakresliSlunicko() {
        zofka.setPenColor(Color.yellow);
        for (int i = 0; i < 12; i++) {
            zofka.move(5);
            zofka.turnRight(10);
            zofka.move(5);
            zofka.turnRight(10);
            zofka.move(5);
            zofka.setPenWidth(5);
            zofka.turnLeft(90);
            zofka.move(15);
            zofka.turnRight(180);
            zofka.move(15);
            zofka.turnLeft(80);
            zofka.setPenWidth(10);
        }
    }
}
