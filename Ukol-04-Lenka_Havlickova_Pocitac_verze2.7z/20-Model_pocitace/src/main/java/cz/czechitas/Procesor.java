package cz.czechitas;

public class Procesor {

    private String vyrobce;
    private long rychlost;

    public String getVyrobce() {
        return vyrobce;
    }

    public void setVyrobce(String newValue) {
        vyrobce = newValue;
    }

    public long getRychlost() {
        return rychlost;
    }

    public void setRychlost(long newValue) {
        rychlost = newValue;
    }

    @Override
    public String toString() {
        return "Procesor " +
                "vyrobce=\"" + vyrobce + "\"" + ", " +
                "rychlost=" + rychlost;
    }
}
